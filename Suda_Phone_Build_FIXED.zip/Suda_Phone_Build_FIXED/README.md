# Suda

Suda is an Android offline nearby-chat prototype using Google Nearby Connections.

## What it does
- Finds nearby Suda devices.
- Uses Nearby Connections with `P2P_CLUSTER`.
- Connects to multiple nearby endpoints.
- Sends text messages without mobile data/internet.
- Shows connection status in Hindi.
- Requests required runtime permissions.

## Important
This is direct nearby device communication. `P2P_CLUSTER` does **not** automatically create a true multi-hop internet-like mesh where messages travel through a chain of phones. A future version can implement explicit relay/routing logic.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Use JDK 17.
4. Connect two or more Android phones.
5. Install the app on each phone.
6. Grant nearby/Bluetooth/location permissions.
7. Press "डिवाइस खोजें व कनेक्ट करें" on both phones.
8. Send a message.

## App ID
`com.example.suda`

## Version
1.0
